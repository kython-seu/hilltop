package com.javen.validate.base;

import com.jfinal.validate.Validator;

/**
 * 通用校验器
 * @author Javen
 * 2016年4月2日
 */

public abstract class BaseValidator extends Validator {

}
