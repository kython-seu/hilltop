package com.javen.weixin.user;

/**
 * @author Javen
 * 2016年5月22日
 */
public class GetUserInfo {
	private UserConfig[] user_list;

	public UserConfig[] getUser_list() {
		return user_list;
	}

	public void setUser_list(UserConfig[] user_list) {
		this.user_list = user_list;
	}

	
	
	
}
